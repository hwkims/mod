if (document.getElementById("formLogin") === null) {
    document.write("<FORM name='formLogin' method='post' id='formLogin'></FORM>");
}

NgbEVM.RaiseEvent(NgbEVM.k_nEventType_onPageEnd);
NgbEVM.ReplaceEventHandler();

var google_conversion_id = 977536595;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;

if (document.location.host != 'member.nexon.com' && document.location.host != 'user.nexon.com') {
    if (document.location.protocol == "https:")
        document.write('<scr' + 'ipt type="text/javascript" src="https://www.googleadservices.com/pagead/conversion.js"></scr' + 'ipt>');
    else
        document.write('<scr' + 'ipt type="text/javascript" src="http://www.googleadservices.com/pagead/conversion.js"></scr' + 'ipt>');
}
// 구글 어날리틱스 스크립트 삽입 시작
// (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
// (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
// m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
// })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

// ga('create', 'UA-88753729-1', 'auto');
// ga('send', 'pageview');
// // 구글 어날리틱스 스크립트 삽입 끝