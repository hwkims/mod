(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [452], {
        897: function(a, e, t) {
            Promise.resolve().then(t.bind(t, 1601))
        },
        6409: function(a, e, t) {
            "use strict";
            t.d(e, {
                J: function() {
                    return o
                }
            });
            var n = t(216),
                r = t(3773);
            let l = {
                male: [{
                    index: "",
                    url: "avatar/male/(male)_01_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_01_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_02_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_02_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_03_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_03_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_04_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_04_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_05_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_05_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_06_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_06_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_07_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_07_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_08_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_08_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_09_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_09_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_10_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_10_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_11_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_11_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_12_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_12_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_13_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_13_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_14_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_14_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_15_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_15_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_16_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_16_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_17_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_17_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_18_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_18_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }],
                female: [{
                    index: "",
                    url: "avatar/female/(female)_01_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_01_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_02_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_02_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_03_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_03_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_04_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_04_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_05_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_05_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_06_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_06_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_07_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_07_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_08_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_08_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_09_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_09_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_10_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_10_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_11_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_11_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_12_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_12_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_13_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_13_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_14_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_14_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_15_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_15_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_16_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_16_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_17_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_17_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_18_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_18_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }]
            };

            function o() {
                return {
                    async getStoreItems(a) {
                        var e, t;
                        if ("avatar" === a.type) return l[a.gender];
                        let r = await n.I.request({
                            method: "GET",
                            url: "/30th/avatar/items",
                            params: a
                        });
                        return (null !== (t = null == r ? void 0 : null === (e = r.data) || void 0 === e ? void 0 : e.data) && void 0 !== t ? t : {}).items
                    },
                    async getAvatarItem(a) {
                        var e, t;
                        let r = await n.I.request({
                            method: "GET",
                            url: "/30th/avatar/item",
                            params: a
                        });
                        return null !== (t = null == r ? void 0 : null === (e = r.data) || void 0 === e ? void 0 : e.data) && void 0 !== t ? t : {}
                    },
                    saveAvatar: a => n.I.request({
                        method: "POST",
                        url: "/30th/avatar",
                        data: a
                    }),
                    async getAvatar() {
                        var a, e;
                        let t = await n.I.request({
                            method: "GET",
                            url: "/30th/avatar"
                        });
                        return null !== (e = null == t ? void 0 : null === (a = t.data) || void 0 === a ? void 0 : a.data) && void 0 !== e ? e : {}
                    },
                    submitContest(a) {
                        let e = (0, r.W)();
                        return n.I.request({
                            method: "POST",
                            url: "/30th/avatar/contest",
                            data: { ...a,
                                categoryId: e
                            }
                        })
                    }
                }
            }
        },
        1601: function(a, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                default: function() {
                    return D
                }
            });
            var n = t(6063),
                r = t(4617),
                l = t(4673),
                o = t.n(l),
                s = t(3720),
                i = t.n(s),
                m = t(1586),
                c = t(3962),
                v = t(2729),
                _ = t(5145),
                d = t(6409),
                u = t(1280),
                f = t(500),
                g = t(1774),
                x = t(4202),
                p = t(2230),
                h = t(1818),
                b = t(158),
                C = t(9745),
                y = t(992),
                N = t(3773),
                A = t(1003),
                E = t(3723),
                j = t(5986);
            let k = (0, g.default)(() => Promise.all([t.e(198), t.e(161), t.e(921)]).then(t.bind(t, 4921)), {
                    loadableGenerated: {
                        webpack: () => [4921]
                    },
                    ssr: !1
                }),
                w = (0, g.default)(() => Promise.all([t.e(198), t.e(836), t.e(161), t.e(397)]).then(t.bind(t, 3397)), {
                    loadableGenerated: {
                        webpack: () => [3397]
                    },
                    ssr: !1
                }),
                U = o().bind(i()),
                I = [{
                    id: "avatar-maker",
                    text: "아바타 만들기",
                    a2sValue: "Create"
                }, {
                    id: "contest",
                    text: "베스트 드레서 콘테스트",
                    a2sValue: "Bestdresser"
                }, {
                    id: "hall-of-fame",
                    text: "명예의 전당",
                    a2sValue: "HOF"
                }],
                K = [{
                    contentId: "181778",
                    retalkId: 1949,
                    categoryId: 67,
                    categoryName: "7월",
                    title: "아주몹시머찐나~!",
                    content: "친구ㄱг무엇을뜻ㅎг는줄○гㄴı\xbf",
                    url: null,
                    thumbnailUrl: "https://retalk-file.nexon.com/retalk/20240701/690fe8b7-ea84-4c54-9436-5910ce9acb11/avatar.gif",
                    profileImageUrl: null,
                    shareUrl: null,
                    emotionLikeCount: 147,
                    reportCount: 0,
                    deleteCount: 2,
                    subDeleteCount: 0,
                    releaseOffCount: 0,
                    commentCount: 17,
                    subCommentCount: 0,
                    releaseCode: "ON",
                    userReleaseCode: "ON",
                    adminReleaseCode: "ON",
                    commentAllowYn: "Y",
                    deleteYn: "N",
                    adminYn: "N",
                    userId: 4844085,
                    nickName: "윤미장군",
                    contentUserTag: [],
                    userTag: [],
                    tag: [],
                    metaData: null,
                    recommendYn: "N",
                    isSticky: !1,
                    guid: "1426166584",
                    readCount: 2994,
                    modifyDate: 1719800381,
                    createDate: 1719800381,
                    modifyUserId: 0,
                    sort: ["147", "181778"],
                    userContentEmotion: null
                }, {
                    contentId: "185518",
                    retalkId: 1949,
                    categoryId: 67,
                    categoryName: "7월",
                    title: "그때 우리는 모두 하나였다.",
                    content: "하나된 그때  그 시절",
                    url: null,
                    thumbnailUrl: "https://retalk-file.nexon.com/retalk/20240701/fcd331cb-e12f-43c0-a30a-04edd2b06f2e/avatar.gif",
                    profileImageUrl: null,
                    shareUrl: null,
                    emotionLikeCount: 122,
                    reportCount: 0,
                    deleteCount: 1,
                    subDeleteCount: 0,
                    releaseOffCount: 0,
                    commentCount: 12,
                    subCommentCount: 0,
                    releaseCode: "ON",
                    userReleaseCode: "ON",
                    adminReleaseCode: "ON",
                    commentAllowYn: "Y",
                    deleteYn: "N",
                    adminYn: "N",
                    userId: 4856068,
                    nickName: "GG84881187C0BEFA",
                    contentUserTag: [],
                    userTag: [],
                    tag: [],
                    metaData: null,
                    recommendYn: "N",
                    isSticky: !1,
                    guid: "554382288",
                    readCount: 1567,
                    modifyDate: 1719821786,
                    createDate: 1719821786,
                    modifyUserId: 0,
                    sort: ["122", "185518"],
                    userContentEmotion: null
                }, {
                    contentId: "215970",
                    retalkId: 1949,
                    categoryId: 67,
                    categoryName: "7월",
                    title: "올라타자 고수",
                    content: "/갈비탕 어디갔나요",
                    url: null,
                    thumbnailUrl: "https://retalk-file.nexon.com/retalk/20240707/d51d255d-69de-42a8-b45c-8c83069c2ff6/avatar.gif",
                    profileImageUrl: null,
                    shareUrl: null,
                    emotionLikeCount: 119,
                    reportCount: 0,
                    deleteCount: 0,
                    subDeleteCount: 0,
                    releaseOffCount: 0,
                    commentCount: 5,
                    subCommentCount: 0,
                    releaseCode: "ON",
                    userReleaseCode: "ON",
                    adminReleaseCode: "ON",
                    commentAllowYn: "Y",
                    deleteYn: "N",
                    adminYn: "N",
                    userId: 4957578,
                    nickName: "탐스제로를마셔라",
                    contentUserTag: [],
                    userTag: [],
                    tag: [],
                    metaData: null,
                    recommendYn: "N",
                    isSticky: !1,
                    guid: "1308904256",
                    readCount: 1119,
                    modifyDate: 1720364038,
                    createDate: 1720364038,
                    modifyUserId: 0,
                    sort: ["119", "215970"],
                    userContentEmotion: null
                }],
                q = "Avatar_Main";

            function S() {
                var a, e, t;
                let {
                    isMobile: l
                } = (0, x.dD)(), o = (0, r.useContext)(m.InfaceContext), s = (0, r.useRef)(null), i = (0, r.useRef)(null), {
                    randomContestItems: g
                } = (0, x.OM)(), [S, O] = (0, r.useState)(!0), [D, T] = (0, r.useState)(0), [P, R] = (0, r.useState)(!1), [Y, M] = (0, r.useState)(""), B = (0, r.useRef)(null), H = (0, r.useRef)(null), F = (0, r.useRef)(null), [J, V] = (0, r.useState)(0), {
                    data: Z,
                    mutate: W
                } = (0, c.ZP)(() => o.loaded ? "saved-avatar-data" : null, async () => {
                    let a = await (0, d.J)().getAvatar();
                    if (null == a || !a.avatarInfo) return null; {
                        let e = null == a ? void 0 : a.avatarInfo;
                        try {
                            return JSON.parse(e)
                        } catch (a) {
                            return null
                        }
                    }
                }), {
                    data: G,
                    mutate: L
                } = (0, c.ZP)(() => o.userProfile ? "my-content" : null, async () => {
                    var a;
                    let {
                        userProfile: e
                    } = o, t = e.local_session_user_id, n = (0, N.W)(), r = await (0, u.V)().getMyContents({
                        guid: t,
                        categoryId: n
                    });
                    return null == r ? void 0 : null === (a = r.data) || void 0 === a ? void 0 : a.data[0]
                });
                (0, r.useEffect)(() => {
                    window.addEventListener("scroll", function() {
                        if (!s.current || !i.current) return;
                        let a = i.current.getBoundingClientRect();
                        return window.innerHeight - a.y > 100 ? T(2) : s.current.getBoundingClientRect().y < 100 ? T(1) : T(0)
                    })
                }, []), (0, r.useEffect)(() => {
                    (async function() {
                        var a, e, t;
                        let n = sessionStorage.getItem(v.mb);
                        sessionStorage.getItem(v.R0) && (null === (t = window.inface) || void 0 === t ? void 0 : null === (e = t.auth) || void 0 === e ? void 0 : null === (a = e.isSignedIn) || void 0 === a ? void 0 : a.call(e)) && (sessionStorage.removeItem(v.R0), M(n), R(!0), W())
                    })()
                }, [W]);
                let z = async () => {
                    (o.userProfile || await _.lp.openEnterMaker()) && R(!0)
                };
                (0, r.useEffect)(() => {
                    if (!B.current) return;
                    let a = B.current,
                        e = p.Z.create(a, {
                            resize: !0
                        }),
                        t = 1;

                    function n(a, e) {
                        return Math.random() * (e - a) + a
                    }
                    let r = 1e3 / 30,
                        l = window.performance.now();
                    requestAnimationFrame(function a(o) {
                        if (!B.current) return;
                        let s = o - l;
                        return s < r || ((l = o - s % r, t % 5 != 0) ? t++ : (t = 1, e({
                            particleCount: 1,
                            spread: 1360,
                            ticks: Math.max(200, (Date.now() + 1.5 - Date.now()) / 1.5 * 500),
                            origin: {
                                x: Math.random(),
                                y: 0
                            },
                            startVelocity: 0,
                            colors: [
                                ["#00ff11", "#fb59b7", "#9e7cfd", "#ffe12b"][Math.floor(4 * Math.random())]
                            ],
                            gravity: n(.6, .9),
                            scalar: n(1, 1.3),
                            drift: n(-.4, .4)
                        }))), requestAnimationFrame(a)
                    })
                }, []);
                let Q = (0, r.useCallback)(a => {
                        let {
                            children: e,
                            className: t
                        } = a;
                        return l ? (0, n.jsx)(E.tq, {
                            slidesPerView: "auto",
                            centeredSlides: !0,
                            navigation: {
                                nextEl: H.current,
                                prevEl: F.current
                            },
                            modules: [j.W_],
                            className: U("slide-container", t),
                            onBeforeInit: a => {
                                a.params.navigation.prevEl = H.current, a.params.navigation.nextEl = F.current
                            },
                            onSlideChange: a => {
                                V(a.realIndex)
                            },
                            children: e
                        }) : (0, n.jsx)("div", {
                            className: U("normal-container", t),
                            children: e
                        })
                    }, [l]),
                    X = a => {
                        let e = K[a].contentId;
                        (0, C.D)(q, {
                            name: "HOF",
                            type: "Winner"
                        }), location.href = "https://enter.nexon.com/30th/avatar-contest/items?detail=".concat(e)
                    };
                return (0, n.jsxs)("section", {
                    className: U("avatar-event-container"),
                    children: [(0, n.jsx)(h.Hn, {
                        sharingUrl: "https://enter.nexon.com/30th/avatar",
                        sharingA2S: {
                            object: q,
                            name: "Anchor"
                        },
                        children: I.map((a, e) => (0, n.jsx)(C.Z, {
                            "data-a2s-web-obj": q,
                            "data-a2s-option-name": "Anchor",
                            "data-a2s-option-value": a.a2sValue,
                            "data-a2s-option-pagecode": "65478",
                            children: (0, n.jsx)("a", {
                                className: U("anchor", e === D && "on"),
                                href: "#".concat(a.id),
                                children: a.text
                            })
                        }, a.id))
                    }), (0, n.jsx)("div", {
                        className: U("avatar-main-section"),
                        children: (0, n.jsxs)("div", {
                            className: U("avatar-main-container"),
                            children: [(0, n.jsxs)("div", {
                                className: U("avatar-main-title"),
                                children: [(0, n.jsx)("div", {
                                    className: U("avatar-main-title-star-1")
                                }), (0, n.jsx)("div", {
                                    className: U("avatar-main-title-star-2")
                                }), (0, n.jsx)("div", {
                                    className: U("avatar-main-title-star-3")
                                })]
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-qplay-ui")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-character-01")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-character-02")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-textbox-01")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-textbox-02")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-textbox-03")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-textbox-04")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-main-textbox-05")
                            })]
                        })
                    }), (0, n.jsxs)("div", {
                        className: U("avatar-maker-section"),
                        id: "avatar-maker",
                        children: [(0, n.jsx)("div", {
                            className: U("avatar-maker-event-line-container"),
                            children: Array.from({
                                length: 2
                            }).map((a, e) => (0, n.jsx)("div", {
                                className: U("avatar-maker-event-line")
                            }, e))
                        }), (0, n.jsxs)("div", {
                            className: U("avatar-maker-container"),
                            children: [(0, n.jsx)("div", {
                                className: U("avatar-maker-title")
                            }), (0, n.jsxs)("div", {
                                className: U("avatar-maker-notice"),
                                children: ["* 아바타는 계속 만들 수 있으나, ", (0, n.jsx)("span", {
                                    className: U("mobile-block")
                                }), "콘테스트 제출은 넥슨ID 당 1회만 가능합니다."]
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-balloon-01")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-balloon-02")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-balloon-03")
                            }), (0, n.jsxs)("div", {
                                className: U("avatar-maker-qplay-ui"),
                                children: [!Z && (0, n.jsx)(h.Nn, {
                                    className: U("avatar-maker-default-avatar")
                                }), Z && (0, n.jsx)("div", {
                                    className: U("avatar-ui-wrapper"),
                                    children: (0, n.jsxs)("div", {
                                        className: U("avatar-ui-container"),
                                        children: [(0, n.jsx)("div", {
                                            className: U("avatar-ui-my-avatar"),
                                            children: (0, n.jsx)(k, {
                                                avatarData: Z,
                                                className: U("canvas-container")
                                            }, JSON.stringify(Z))
                                        }), (0, n.jsx)("div", {
                                            className: U("avatar-ui-wearing-items-wrapper"),
                                            children: (0, n.jsx)("ul", {
                                                className: U("avatar-ui-wearing-items"),
                                                children: Z && Array.from({
                                                    length: 8
                                                }).map((a, e) => {
                                                    var t;
                                                    let r = v.P[e],
                                                        l = null === (t = Z[r]) || void 0 === t ? void 0 : t.store;
                                                    return (0, n.jsx)("li", {
                                                        className: U("wearing-item-slot", "wearing-item-".concat(r)),
                                                        children: l && (0, n.jsx)("div", {
                                                            className: U("wearing-item-image-container"),
                                                            children: (0, n.jsx)(y.default, {
                                                                alt: "착용 아이템",
                                                                width: "92",
                                                                height: "102",
                                                                className: U("wearing-item-image"),
                                                                src: (0, f.xn)(v.Wl, l.fileUrl)
                                                            })
                                                        })
                                                    }, r)
                                                })
                                            })
                                        })]
                                    })
                                })]
                            }), (0, n.jsx)(C.Z, {
                                "data-a2s-web-obj": q,
                                "data-a2s-option-name": "Avatar",
                                "data-a2s-option-type": Z ? "Edit" : "Create",
                                children: (0, n.jsx)("button", {
                                    className: U("goto-avatar-maker-button", Z && "edit-avatar-button"),
                                    onClick: () => {
                                        (0, A.k)("event", "avatar_아바타만들기"), z()
                                    }
                                })
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-textbox-01")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-textbox-02")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-textbox-03")
                            }), (0, n.jsx)("div", {
                                className: U("avatar-maker-character-group")
                            })]
                        })]
                    }), (0, n.jsx)("div", {
                        className: U("contest-section", !(g && g.length > 0) && "no-current-avatar"),
                        id: "contest",
                        ref: s,
                        children: (0, n.jsxs)("div", {
                            className: U("contest-container"),
                            children: [(0, n.jsx)("div", {
                                className: U("contest-title")
                            }), (0, n.jsx)("div", {
                                className: U("contest-item-01")
                            }), (0, n.jsx)("div", {
                                className: U("contest-item-02")
                            }), (0, n.jsx)("div", {
                                className: U("contest-item-03")
                            }), (0, n.jsx)("div", {
                                className: U("contest-item-04")
                            }), (0, n.jsxs)("div", {
                                className: U("contest-tv"),
                                children: [(0, n.jsx)("div", {
                                    className: U("contest-tv-avatar"),
                                    children: G && (0, n.jsx)(y.default, {
                                        alt: "내 아바타",
                                        width: "288",
                                        height: "364",
                                        className: U("contest-tv-my-avatar"),
                                        src: G.thumbnailUrl
                                    })
                                }), !G && (0, n.jsx)("div", {
                                    className: U("contest-tv-bubble")
                                })]
                            }), G ? (0, n.jsx)(C.Z, {
                                "data-a2s-web-obj": q,
                                "data-a2s-option-name": "Bestdresser",
                                "data-a2s-option-type": "My",
                                "data-a2s-option-pagecode": "65478",
                                children: (0, n.jsx)(b.default, {
                                    className: U("contest-my-avatar-button"),
                                    href: "/avatar-contest/items?detail=".concat(G.contentId),
                                    target: "_blank",
                                    children: "제출한 아바타 보러가기"
                                })
                            }) : (0, n.jsx)(C.Z, {
                                "data-a2s-web-obj": q,
                                "data-a2s-option-name": "Bestdresser",
                                "data-a2s-option-type": "Create",
                                "data-a2s-option-pagecode": "65478",
                                children: (0, n.jsx)("button", {
                                    className: U("contest-participate-button"),
                                    onClick: () => {
                                        (0, A.k)("event", "avatar_콘테스트참여하기"), z()
                                    },
                                    children: "아바타 만들고 콘테스트 참여하기"
                                })
                            }), (0, n.jsx)("div", {
                                className: U("contest-notice")
                            }), (0, n.jsxs)("div", {
                                className: U("contest-aqua-avatar-01"),
                                children: [(0, n.jsx)("div", {
                                    className: U("contest-aqua-avatar-textbox-01")
                                }), (0, n.jsx)("div", {
                                    className: U("contest-aqua-avatar-bg-01")
                                }), (0, n.jsx)("div", {
                                    className: U("contest-avatar-01")
                                }), (0, n.jsx)("div", {
                                    className: U("contest-aqua-01")
                                })]
                            }), (0, n.jsxs)("div", {
                                className: U("contest-aqua-avatar-02"),
                                children: [(0, n.jsx)("div", {
                                    className: U("contest-aqua-avatar-bg-02")
                                }), (0, n.jsx)("div", {
                                    className: U("contest-avatar-02")
                                }), (0, n.jsx)("div", {
                                    className: U("contest-aqua-02")
                                })]
                            }), (0, n.jsx)("div", {
                                className: U("contest-gift")
                            }), (0, n.jsxs)("ul", {
                                className: U("contest-gift-announcement"),
                                children: [(0, n.jsx)("li", {
                                    children: "* 차수별 1회에 한해 참여작을 제출할 수 있습니다."
                                }), (0, n.jsx)("li", {
                                    children: "* 추천 수, 명예의 전당 등재 여부와 상관없이 콘테스트 참여 기준으로 추첨이 진행됩니다."
                                }), (0, n.jsx)("li", {
                                    children: "* 당첨자 발표 및 상품 수령에 대한 자세한 내용은 유의사항을 통해 확인하실 수 있습니다."
                                })]
                            }), g && g.length > 0 && (0, n.jsxs)("div", {
                                className: U("contest-codi-section"),
                                children: [(0, n.jsx)("div", {
                                    className: U("contest-current-codi")
                                }), (0, n.jsxs)("div", {
                                    className: U("contest-codi-list"),
                                    children: [(0, n.jsx)("div", {
                                        className: U("contest-codi-list-item", "contest-empty")
                                    }), (0, n.jsx)("div", {
                                        className: U("contest-codi-list-item", "contest-empty")
                                    }), g.map(a => (0, n.jsx)("div", {
                                        className: U("contest-codi-list-item", "contest-not-empty"),
                                        children: (0, n.jsx)(y.default, {
                                            alt: "현재 콘테스트 참여중인 코디",
                                            width: "288",
                                            height: "364",
                                            className: U("contest-codi-image"),
                                            src: a.thumbnailUrl
                                        })
                                    }, a.contentId)), (0, n.jsx)("div", {
                                        className: U("contest-codi-list-item", "contest-empty")
                                    }), (0, n.jsx)("div", {
                                        className: U("contest-codi-list-item", "contest-empty")
                                    })]
                                })]
                            }), (0, n.jsx)(C.Z, {
                                "data-a2s-web-obj": q,
                                "data-a2s-option-name": "Contest_Other",
                                "data-a2s-option-pagecode": "65478",
                                children: (0, n.jsx)(b.default, {
                                    className: U("goto-contest-button"),
                                    href: "/avatar-contest",
                                    target: "_blank"
                                })
                            })]
                        })
                    }), (0, n.jsxs)("div", {
                        className: U("honor-section", !S && "yet"),
                        id: "hall-of-fame",
                        ref: i,
                        children: [(0, n.jsx)("canvas", {
                            className: U("confetti-canvas"),
                            ref: B
                        }), (0, n.jsxs)("div", {
                            className: U("honor-container"),
                            children: [(0, n.jsx)("div", {
                                className: U("honor-title")
                            }), (0, n.jsx)("div", {
                                onClick: () => X(J),
                                className: U("fixed-honor-nickname"),
                                children: (0, n.jsx)("div", {
                                    children: null === (a = K[J]) || void 0 === a ? void 0 : a.nickName
                                })
                            }), (0, n.jsxs)("div", {
                                onClick: () => X(J),
                                className: U("fixed-honor-bubble"),
                                children: [(0, n.jsx)("h3", {
                                    className: U("honor-bubble-title"),
                                    children: null === (e = K[J]) || void 0 === e ? void 0 : e.title
                                }), (0, n.jsx)(h.uU, {
                                    className: U("honor-bubble-description"),
                                    children: null === (t = K[J]) || void 0 === t ? void 0 : t.content
                                })]
                            }), S && (0, n.jsxs)(Q, {
                                className: U("honor-list"),
                                children: [K.map((a, e) => {
                                    function t(a) {
                                        let {
                                            children: t
                                        } = a;
                                        return (0, n.jsx)("div", {
                                            onClick: () => X(e),
                                            className: U("honor-list-item-link"),
                                            children: t
                                        })
                                    }
                                    return (0, n.jsx)(E.o5, {
                                        className: U("honor-list-item"),
                                        children: (0, n.jsxs)("div", {
                                            children: [(0, n.jsx)(t, {
                                                children: (0, n.jsx)("div", {
                                                    className: U("honor-nickname"),
                                                    children: a.nickName
                                                })
                                            }), (0, n.jsx)(t, {
                                                children: (0, n.jsx)("div", {
                                                    className: U("honor-avatar"),
                                                    children: (0, n.jsx)(y.default, {
                                                        className: U("honor-avatar-image"),
                                                        alt: "명예의 전당 아바타",
                                                        src: a.thumbnailUrl,
                                                        width: "288",
                                                        height: "364"
                                                    })
                                                })
                                            }), (0, n.jsx)("div", {
                                                className: U("honor-avatar-stage")
                                            }), (0, n.jsx)(t, {
                                                children: (0, n.jsxs)("div", {
                                                    className: U("honor-bubble"),
                                                    children: [(0, n.jsx)("h3", {
                                                        className: U("honor-bubble-title"),
                                                        children: a.title
                                                    }), (0, n.jsx)(h.uU, {
                                                        className: U("honor-bubble-description"),
                                                        children: a.content
                                                    })]
                                                })
                                            })]
                                        })
                                    }, a.contentId)
                                }), (0, n.jsx)("button", {
                                    ref: H,
                                    className: U("swiper-button-prev")
                                }), (0, n.jsx)("button", {
                                    ref: F,
                                    className: U("swiper-button-next")
                                })]
                            }), (0, n.jsx)("div", {
                                className: U("honor-teaser")
                            })]
                        })]
                    }), (0, n.jsxs)("div", {
                        className: U("footer-container"),
                        children: [(0, n.jsx)("div", {
                            className: U("footer-notice")
                        }), (0, n.jsxs)("ul", {
                            className: U("footer-notice-list"),
                            children: [(0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "아바타는 횟수 제한 없이 생성할 수 있으나, 콘테스트 제출은 넥슨ID 당 차수별 1회만 할 수 있습니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "콘테스트 제출 시 넥슨 홈페이지 닉네임과 제출 단계에서 입력한 코디 제목 및 설명이 노출되며 참여 이후에는 정보를 변경 또는 삭제할 수 없습니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "부적절한 닉네임, 코디 제목 및 설명 등이 확인될 경우 제출한 콘테스트 참여작이 삭제될 수 있으며, 삭제 시 재참여할 수 없습니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "비정상적인 방법(타인의 넥슨ID/개인정보 도용 등)으로 이벤트에 참여하거나 보상을 수령할 경우, 추첨에서 제외되거나 당첨이 취소될 수 있습니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "차수별 이벤트 기간에 참여작을 제출한 분들을 대상으로 추첨이 진행됩니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "추첨은 추천 수, 명예의 전당 등재 여부와 상관없이 참여 여부를 기준으로 진행됩니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "추첨 결과는 다음 달 14일 별도 공지사항 및 넥슨쪽지를 통해 안내 드리겠습니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "[1차 콘테스트 당첨 발표일] 2024년 8월 14일(수)"
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "[2차 콘테스트 당첨 발표일] 2024년 9월 14일(토)"
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "1차 콘테스트에서 '온라인 문화상품권 3만원' 당첨 시, 상품 지급을 위한 개인정보 수집이 진행됩니다."
                            }), (0, n.jsx)("li", {
                                className: U("footer-notice-list-item"),
                                children: "상품별 자세한 수령 방법은 당첨 안내 공지사항을 통해 안내 드리겠습니다."
                            })]
                        })]
                    }), (0, n.jsx)("div", {
                        className: U("css-preloader")
                    }), P && (0, n.jsx)(w, {
                        onClose: () => {
                            R(!1), M(""), W(), L()
                        },
                        tempSavedAvatar: Y,
                        userProfile: null == o ? void 0 : o.userProfile
                    })]
                })
            }
            var O = t(6413);

            function D() {
                return (0, O.Z)(), (0, n.jsx)(S, {})
            }
        },
        2729: function(a, e, t) {
            "use strict";
            t.d(e, {
                $h: function() {
                    return o
                },
                JP: function() {
                    return l
                },
                P: function() {
                    return r
                },
                R0: function() {
                    return i
                },
                Wl: function() {
                    return n
                },
                mb: function() {
                    return s
                },
                yg: function() {
                    return m
                }
            });
            let n = "https://enter.nexon.com/qplay-avatar-assets/",
                r = ["hair", "clothes", "eye", "ear", "mouth", "bg", "effect", "wing"],
                l = {
                    avatar: "아바타",
                    hair: "헤어",
                    clothes: "의상",
                    face: "얼굴",
                    eye: "눈",
                    ear: "귀",
                    mouth: "입",
                    bg: "배경",
                    accessory: "소품",
                    effect: "이펙트",
                    wing: "날개"
                },
                o = [{
                    assetType: "avatar"
                }, {
                    assetType: "hair"
                }, {
                    assetType: "clothes"
                }, {
                    assetType: "face",
                    children: [{
                        assetType: "eye"
                    }, {
                        assetType: "ear"
                    }, {
                        assetType: "mouth"
                    }]
                }, {
                    assetType: "bg"
                }, {
                    assetType: "accessory",
                    children: [{
                        assetType: "effect"
                    }, {
                        assetType: "wing"
                    }]
                }],
                s = "tempSavedAvatar",
                i = "requestOpenAvatarModal",
                m = {
                    bg: {
                        depth: 100
                    },
                    wing: {
                        depth: 200
                    },
                    bgDeco: {
                        depth: 300
                    },
                    avatar: {
                        depth: 400
                    },
                    eye: {
                        depth: 500
                    },
                    mouth: {
                        depth: 600
                    },
                    avatarHead: {
                        depth: 700
                    },
                    hair: {
                        depth: 800
                    },
                    clothes: {
                        depth: 900
                    },
                    ear: {
                        depth: 1e3
                    },
                    eye1: {
                        depth: 1100
                    },
                    mouth1: {
                        depth: 1200
                    },
                    bgDesk: {
                        depth: 1300
                    },
                    effect: {
                        depth: 1400
                    }
                }
        },
        6413: function(a, e, t) {
            "use strict";
            var n = t(4617),
                r = t(8254);
            e.Z = function() {
                let a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    {
                        baseScale: e = 1,
                        changeScale: t = .75,
                        targetViewportWidth: l = 1e3
                    } = a;
                (0, n.useEffect)(() => {
                    let a = !1,
                        n = function() {
                            let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            try {
                                let {
                                    forceToBase: r = !1
                                } = n, l = document.querySelector("meta[name=viewport]");
                                if (a) {
                                    a = !1;
                                    return
                                }
                                let o = [() => window.innerWidth < 360, () => {
                                    let {
                                        navigator: a
                                    } = window;
                                    return a.userAgent.includes("SM-F")
                                }].some(a => a());
                                o && (a = !0);
                                let s = o ? t : e,
                                    i = r ? e : s;
                                l.setAttribute("content", "width=device-width, initial-scale=".concat(i, ", maximum-scale=").concat(i, ", minimum-scale=").concat(i, ", user-scalable=no"))
                            } catch (a) {
                                r.Tb(a)
                            }
                        };
                    return n(), window.addEventListener("resize", n), () => {
                        window.removeEventListener("resize", n), n({
                            forceToBase: !0
                        })
                    }
                }, [e, t, l])
            }
        },
        3720: function(a) {
            a.exports = {
                "mobile-block": "C_AvatarEvent_mobile-block__D35XD",
                "avatar-event-container": "C_AvatarEvent_avatar-event-container__6WJwV",
                anchor: "C_AvatarEvent_anchor__tyrwR",
                on: "C_AvatarEvent_on__GUgj2",
                "avatar-main-section": "C_AvatarEvent_avatar-main-section__kPLkq",
                "avatar-main-container": "C_AvatarEvent_avatar-main-container__4PmYO",
                "avatar-main-title": "C_AvatarEvent_avatar-main-title__RazJE",
                "avatar-main-title-star-1": "C_AvatarEvent_avatar-main-title-star-1__NVCSW",
                twinkle: "C_AvatarEvent_twinkle__Y2Ix6",
                "avatar-main-title-star-2": "C_AvatarEvent_avatar-main-title-star-2__tO5nu",
                "avatar-main-title-star-3": "C_AvatarEvent_avatar-main-title-star-3__x01Hq",
                "avatar-main-qplay-ui": "C_AvatarEvent_avatar-main-qplay-ui__2BKYr",
                "avatar-main-character-01": "C_AvatarEvent_avatar-main-character-01__KKFbz",
                "avatar-main-character-02": "C_AvatarEvent_avatar-main-character-02__AC3v8",
                "avatar-main-textbox-01": "C_AvatarEvent_avatar-main-textbox-01__XqZIy",
                "malpoongsun-up": "C_AvatarEvent_malpoongsun-up__iOoS5",
                "avatar-main-textbox-02": "C_AvatarEvent_avatar-main-textbox-02__1hggT",
                "avatar-main-textbox-03": "C_AvatarEvent_avatar-main-textbox-03__d_qth",
                "avatar-main-textbox-04": "C_AvatarEvent_avatar-main-textbox-04__Bl_Et",
                "avatar-main-textbox-05": "C_AvatarEvent_avatar-main-textbox-05__Is21S",
                "avatar-maker-section": "C_AvatarEvent_avatar-maker-section__S0Aiz",
                "avatar-maker-event-line-container": "C_AvatarEvent_avatar-maker-event-line-container__2xboT",
                "rolling-banner": "C_AvatarEvent_rolling-banner__1Ytf3",
                "avatar-maker-event-line": "C_AvatarEvent_avatar-maker-event-line__K1AkZ",
                "avatar-maker-container": "C_AvatarEvent_avatar-maker-container__s14sO",
                "avatar-maker-title": "C_AvatarEvent_avatar-maker-title__G7Gm6",
                "avatar-maker-notice": "C_AvatarEvent_avatar-maker-notice__0CSKF",
                "avatar-maker-qplay-ui": "C_AvatarEvent_avatar-maker-qplay-ui__YXrXr",
                "avatar-ui-wrapper": "C_AvatarEvent_avatar-ui-wrapper__rOfIM",
                "avatar-ui-container": "C_AvatarEvent_avatar-ui-container__EjFUt",
                "avatar-ui-my-avatar": "C_AvatarEvent_avatar-ui-my-avatar__21uAg",
                "canvas-container": "C_AvatarEvent_canvas-container__hV703",
                "avatar-ui-wearing-items-wrapper": "C_AvatarEvent_avatar-ui-wearing-items-wrapper__wOiIz",
                "avatar-ui-wearing-items": "C_AvatarEvent_avatar-ui-wearing-items__EJHE9",
                "wearing-item-slot": "C_AvatarEvent_wearing-item-slot___xFTg",
                "wearing-item-image-container": "C_AvatarEvent_wearing-item-image-container__Q7Vy9",
                "wearing-item-image": "C_AvatarEvent_wearing-item-image__DcfcK",
                "avatar-maker-default-avatar": "C_AvatarEvent_avatar-maker-default-avatar__yQt4C",
                "goto-avatar-maker-button": "C_AvatarEvent_goto-avatar-maker-button__Ujp_o",
                "edit-avatar-button": "C_AvatarEvent_edit-avatar-button__Bvbsi",
                "avatar-maker-character-group": "C_AvatarEvent_avatar-maker-character-group__lrJ56",
                "avatar-maker-balloon-01": "C_AvatarEvent_avatar-maker-balloon-01__Q5L_j",
                "doongdoong-balloon-01": "C_AvatarEvent_doongdoong-balloon-01__UXH0v",
                "avatar-maker-balloon-02": "C_AvatarEvent_avatar-maker-balloon-02__SeLnS",
                "doongdoong-balloon-02": "C_AvatarEvent_doongdoong-balloon-02__ra_20",
                "avatar-maker-balloon-03": "C_AvatarEvent_avatar-maker-balloon-03__Va2kf",
                "doongdoong-balloon-03": "C_AvatarEvent_doongdoong-balloon-03__uZL0n",
                "avatar-maker-textbox-01": "C_AvatarEvent_avatar-maker-textbox-01__W_JRt",
                "show-malpoonsun": "C_AvatarEvent_show-malpoonsun__fcQDc",
                "avatar-maker-textbox-02": "C_AvatarEvent_avatar-maker-textbox-02__vjMNT",
                "avatar-maker-textbox-03": "C_AvatarEvent_avatar-maker-textbox-03__ydX_i",
                "contest-section": "C_AvatarEvent_contest-section___JuD_",
                "no-current-avatar": "C_AvatarEvent_no-current-avatar__g3Amr",
                "contest-container": "C_AvatarEvent_contest-container__B5dAl",
                "contest-title": "C_AvatarEvent_contest-title__Vflke",
                "contest-item-01": "C_AvatarEvent_contest-item-01__6Wr10",
                "doongdoong-item": "C_AvatarEvent_doongdoong-item__a7Fer",
                "contest-item-02": "C_AvatarEvent_contest-item-02__iI2Ve",
                "contest-item-03": "C_AvatarEvent_contest-item-03__HgyUi",
                "contest-item-04": "C_AvatarEvent_contest-item-04__QnD3m",
                "contest-tv": "C_AvatarEvent_contest-tv__dyAP_",
                "contest-tv-avatar": "C_AvatarEvent_contest-tv-avatar__XKRwP",
                "contest-tv-my-avatar": "C_AvatarEvent_contest-tv-my-avatar__GoUMM",
                "contest-tv-bubble": "C_AvatarEvent_contest-tv-bubble__Hes0F",
                "contest-my-avatar-button": "C_AvatarEvent_contest-my-avatar-button__HEYLW",
                "contest-participate-button": "C_AvatarEvent_contest-participate-button__3koa5",
                "contest-notice": "C_AvatarEvent_contest-notice__vlM9I",
                "contest-aqua-avatar-01": "C_AvatarEvent_contest-aqua-avatar-01__SPJxS",
                "contest-aqua-avatar-textbox-01": "C_AvatarEvent_contest-aqua-avatar-textbox-01__RZvyf",
                "contest-aqua-avatar-bg-01": "C_AvatarEvent_contest-aqua-avatar-bg-01__24699",
                "contest-avatar-01": "C_AvatarEvent_contest-avatar-01__vP8CN",
                "contest-aqua-01": "C_AvatarEvent_contest-aqua-01__70lQ1",
                "contest-aqua-avatar-02": "C_AvatarEvent_contest-aqua-avatar-02__iF4lM",
                "contest-aqua-avatar-bg-02": "C_AvatarEvent_contest-aqua-avatar-bg-02__8J_nd",
                "contest-avatar-02": "C_AvatarEvent_contest-avatar-02__idx6B",
                "contest-aqua-02": "C_AvatarEvent_contest-aqua-02__45xXf",
                "contest-gift": "C_AvatarEvent_contest-gift__L_zJh",
                "contest-gift-announcement": "C_AvatarEvent_contest-gift-announcement__Wqv7I",
                "contest-codi-section": "C_AvatarEvent_contest-codi-section__K95dl",
                "contest-current-codi": "C_AvatarEvent_contest-current-codi__LHo2w",
                "contest-codi-list": "C_AvatarEvent_contest-codi-list__kRmBG",
                "contest-codi-list-item": "C_AvatarEvent_contest-codi-list-item__yYUlB",
                "contest-empty": "C_AvatarEvent_contest-empty__sc9_h",
                "contest-not-empty": "C_AvatarEvent_contest-not-empty__i5hU9",
                "contest-codi-image": "C_AvatarEvent_contest-codi-image__kkI3r",
                "goto-contest-button": "C_AvatarEvent_goto-contest-button__VMIHR",
                "next-event-notice": "C_AvatarEvent_next-event-notice__edZJm",
                "honor-section": "C_AvatarEvent_honor-section__9uPzP",
                yet: "C_AvatarEvent_yet__lQoyr",
                "honor-container": "C_AvatarEvent_honor-container__ONz66",
                "honor-title": "C_AvatarEvent_honor-title__JUeip",
                "honor-notice": "C_AvatarEvent_honor-notice__YPdV_",
                "honor-list": "C_AvatarEvent_honor-list__yuoKa",
                "normal-container": "C_AvatarEvent_normal-container__rdHve",
                "honor-list-item": "C_AvatarEvent_honor-list-item__P3fzB",
                "slide-container": "C_AvatarEvent_slide-container__sarRx",
                "swiper-button-prev": "C_AvatarEvent_swiper-button-prev__BIsot",
                "swiper-button-next": "C_AvatarEvent_swiper-button-next__4zQ6O",
                "honor-list-item-link": "C_AvatarEvent_honor-list-item-link__pDXWW",
                "fixed-honor-nickname": "C_AvatarEvent_fixed-honor-nickname__s6XFf",
                "honor-nickname": "C_AvatarEvent_honor-nickname__Ltk6K",
                "honor-avatar": "C_AvatarEvent_honor-avatar__5d8sn",
                "honor-avatar-stage": "C_AvatarEvent_honor-avatar-stage__65oFA",
                "honor-avatar-image": "C_AvatarEvent_honor-avatar-image__exTT4",
                "honor-bubble": "C_AvatarEvent_honor-bubble__oM5n9",
                "fixed-honor-bubble": "C_AvatarEvent_fixed-honor-bubble__eopvK",
                "honor-bubble-title": "C_AvatarEvent_honor-bubble-title__uHpmD",
                "honor-bubble-description": "C_AvatarEvent_honor-bubble-description__oo2g1",
                "honor-teaser": "C_AvatarEvent_honor-teaser__sdd2H",
                "footer-container": "C_AvatarEvent_footer-container__16xGQ",
                "footer-notice": "C_AvatarEvent_footer-notice__g2x6m",
                "footer-notice-list": "C_AvatarEvent_footer-notice-list__u221C",
                "footer-notice-list-item": "C_AvatarEvent_footer-notice-list-item__ZwhqF",
                "css-preloader": "C_AvatarEvent_css-preloader__QH_AD",
                "confetti-canvas": "C_AvatarEvent_confetti-canvas__OdG5v"
            }
        }
    },
    function(a) {
        a.O(0, [47, 158, 723, 935, 68, 492, 810, 851, 744], function() {
            return a(a.s = 897)
        }), _N_E = a.O()
    }
]);