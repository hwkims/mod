import React, { Component } from 'react';

class Review extends Component {
  render() {
    return <div></div>;
  }
}

export default Review;
