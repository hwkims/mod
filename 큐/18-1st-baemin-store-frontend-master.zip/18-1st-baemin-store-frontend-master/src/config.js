export const CARTAPI = 'http://10.58.2.56:8000/order/cart';
export const WISHLISTAPI = 'http://10.58.2.56:8000/user/wishlist';
export const BACKAPI = 'http://10.58.2.56:8000';
